﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using static System.IO.File;
using System.Threading.Tasks;

namespace prKol_ind3_Горелова
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] l = File.ReadAllLines("file.txt");
            foreach(string line in l)
            {
                char[] a = line.ToCharArray();
                Array.Reverse(a);
                Console.WriteLine(a);
            }
            Stack<string> l2 = new Stack<string>(l);
            foreach(string lines in l2)
            {
                AppendAllText("file1.txt", (lines) + "\n");
            }
            Console.ReadKey();
        }
        
    }
}
