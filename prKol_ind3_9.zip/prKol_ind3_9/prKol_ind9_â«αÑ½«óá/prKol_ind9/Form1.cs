﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace prKol_ind9
{
    public partial class Form1 : Form
    {
        Stack<string> l = new Stack<string>();
        Stack<string> l2 = new Stack<string>();
        Stack<string> l3 = new Stack<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            if (int.TryParse(textBox1.Text, out int p) && int.TryParse(textBox2.Text, out int p1))
            {
                StreamReader sr = new StreamReader("file.txt");
                if (File.Exists("file.txt"))
                {
                    string[] str = sr.ReadLine().Split(new char[] { ' ' });
                    string a = textBox1.Text;
                    string b = textBox2.Text;
                    if (Convert.ToInt32(a) < Convert.ToInt32(b))
                    {
                        foreach (string bb in str)
                        {
                            if ((int.Parse(bb) > int.Parse(a) && int.Parse(bb) < int.Parse(b)))
                            {
                                l.Push(bb.ToString());

                            }
                            if (Convert.ToInt32(bb) < Convert.ToInt32(a))
                            {
                                l2.Push(bb.ToString());
                            }
                            if (Convert.ToInt32(bb) < Convert.ToInt32(b))
                            {
                                l3.Push(bb.ToString());
                            }
                            count++;
                        }
                    }
                    else MessageBox.Show("Число a должно быть меньше числа b");
                }
                else MessageBox.Show("Файл не найден");
                sr.Close();
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";

                for (int i = 0; i <= count; i++)
                {
                    if (l.Count != 0)
                        textBox3.Text = textBox3.Text + l.Pop() + " ";
                    if (l2.Count != 0)
                        textBox4.Text = textBox4.Text + l2.Pop() + " ";
                    if (l3.Count != 0)
                        textBox5.Text = textBox5.Text + l3.Pop() + " ";
                }

            }
            else MessageBox.Show("Заполните поля");
        }
    }
   
}
